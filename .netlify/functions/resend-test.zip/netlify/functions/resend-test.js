"use strict";

// netlify/functions/resend-test.js
exports.handler = async function(event) {
  const KEY = process.env.RESEND_API_KEY;
  if (!KEY) return { statusCode: 500, body: JSON.stringify({ error: "no key" }) };
  async function tryFrom(from, subject) {
    const r = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: { Authorization: "Bearer " + KEY, "Content-Type": "application/json" },
      body: JSON.stringify({
        from,
        to: ["jmitchell1126@gmail.com"],
        subject,
        html: "<p>Sender test from <strong>" + from + "</strong> \u2014 CapGen</p>"
      })
    });
    return { status: r.status, response: await r.json() };
  }
  const root = await tryFrom("CapGen Reports <reports@aproposgroupllc.com>", "Test 1 \u2014 reports@aproposgroupllc.com");
  const capgen = await tryFrom("CapGen Reports <reports@capgen.aproposgroupllc.com>", "Test 2 \u2014 reports@capgen.aproposgroupllc.com");
  return {
    statusCode: 200,
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ root_domain: root, capgen_subdomain: capgen }, null, 2)
  };
};
