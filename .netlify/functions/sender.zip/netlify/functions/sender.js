"use strict";

// netlify/functions/sender.js
exports.handler = async function() {
  return {
    statusCode: 410,
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      error: "RETIRED",
      message: "Cold outreach path permanently retired (Change Order 1, Section 1). This function will not execute."
    })
  };
};
